function bigger() {
    document.getElementById('img1').style='width: 75%';
}

function smaller() {
    document.getElementById('img1').style='width: 15%';
}

function direction_UP() {
    document.getElementById('img1').src = ('./yep-up.jpg');
}

function direction_DOWN() {
    document.getElementById('img1').src = ('./yep-down.jpg');
}